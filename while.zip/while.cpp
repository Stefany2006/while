//stefany rodas
#include <iostream>
using namespace std;
int main () { int numero;
cout<<"ingrese un numero:";
cin>> numero;
while (numero<=100)
{cout <<"ingrese un numero:";
cin>>numero;}
return 0;
}
